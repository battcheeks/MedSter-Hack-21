from django.apps import AppConfig


class PatientApiConfig(AppConfig):
    name = 'patient_api'
