from django.apps import AppConfig


class DoctorApiConfig(AppConfig):
    name = 'doctor_api'
