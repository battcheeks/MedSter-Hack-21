from django.apps import AppConfig


class OldDataConfig(AppConfig):
    name = 'old_data'
